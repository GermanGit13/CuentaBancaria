import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        String dni = null;
        String nombre = null;
        float cantidad;
        Scanner teclado = new Scanner(System.in);

        Menu nemu = new Menu();

        /*
        System.out.println("Desea crear una nueva cuenta bancaria: ");
        nombre = teclado.nextLine();
        dni = teclado.nextLine();
        CuentaCorriente cuentaCorriente = new CuentaCorriente(nombre, dni);
        System.out.println(cuentaCorriente.getNombre());
        System.out.println("Desea modificar el nombre:");
        cuentaCorriente.setNombre(nombre = teclado.nextLine());
        System.out.println("Cuanto dinero desea ingresar: ");
        cantidad = teclado.nextFloat();
        cuentaCorriente.IngresarDinero(cantidad);
        System.out.println(cuentaCorriente.getSaldo());
        System.out.println(cuentaCorriente.getNombre());
        System.out.println("Cuanto dinero desea retirar: ");
        cantidad = teclado.nextFloat();
        cuentaCorriente.SacarDinero((int) cantidad);

        System.out.println(cuentaCorriente.getSaldo());

         */
    }
}
